import 'package:flutter/material.dart';

void main() => runApp(const HHGrowthApp());

const gold = Color(0xFFD7B56D);
const bg = Color(0xFF090909);
const panel = Color(0xFF151515);

class HHGrowthApp extends StatefulWidget {
  const HHGrowthApp({super.key});
  @override
  State<HHGrowthApp> createState() => _HHGrowthAppState();
}

class _HHGrowthAppState extends State<HHGrowthApp> {
  bool urdu = false;
  String role = 'Owner';
  int tab = 0;

  String t(String en, String ur) => urdu ? ur : en;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HH Growth Studio',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: gold, secondary: gold, surface: panel,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bg, foregroundColor: gold, elevation: 0,
        ),
        cardTheme: CardTheme(
          color: panel, shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0x335D4B2A)),
          ),
        ),
        useMaterial3: true,
      ),
      home: Builder(builder: (context) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('HH GROWTH STUDIO',
              style: TextStyle(letterSpacing: 1.4, fontWeight: FontWeight.w800, fontSize: 16)),
            actions: [
              TextButton(
                onPressed: () => setState(() => urdu = !urdu),
                child: Text(urdu ? 'EN' : 'اردو', style: const TextStyle(color: gold)),
              ),
              PopupMenuButton<String>(
                icon: const Icon(Icons.account_circle_outlined, color: gold),
                onSelected: (v) => setState(() { role = v; tab = 0; }),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'Owner', child: Text('Owner / Admin')),
                  PopupMenuItem(value: 'Employee', child: Text('Employee')),
                  PopupMenuItem(value: 'Client', child: Text('Client')),
                ],
              )
            ],
          ),
          body: IndexedStack(
            index: tab,
            children: [
              DashboardPage(role: role, t: t),
              RecordsPage(title: t('Clients', 'کلائنٹس'), icon: Icons.people_alt_outlined,
                subtitle: t('Client records will appear here.', 'کلائنٹس کا ریکارڈ یہاں نظر آئے گا۔')),
              RecordsPage(title: t('Projects & Tasks', 'پروجیکٹس اور کام'), icon: Icons.work_outline,
                subtitle: t('Track project progress and assigned work.', 'پروجیکٹس کی پیش رفت اور کام دیکھیں۔')),
              RecordsPage(title: t('Finance', 'مالیات'), icon: Icons.account_balance_wallet_outlined,
                subtitle: t('Record income, expenses and invoices.', 'آمدنی، اخراجات اور انوائس درج کریں۔')),
              RecordsPage(title: t('Social Accounts', 'سوشل اکاؤنٹس'), icon: Icons.share_outlined,
                subtitle: t('Manage authorised account references and reports.', 'اجازت یافتہ اکاؤنٹس اور رپورٹس منظم کریں۔')),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            backgroundColor: panel,
            indicatorColor: const Color(0x334F4024),
            selectedIndex: tab,
            onDestinationSelected: (v) => setState(() => tab = v),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.dashboard_outlined), label: t('Home', 'ہوم')),
              NavigationDestination(icon: const Icon(Icons.people_outline), label: t('Clients', 'کلائنٹس')),
              NavigationDestination(icon: const Icon(Icons.task_alt), label: t('Projects', 'پروجیکٹس')),
              NavigationDestination(icon: const Icon(Icons.payments_outlined), label: t('Finance', 'مالیات')),
              NavigationDestination(icon: const Icon(Icons.campaign_outlined), label: t('Social', 'سوشل')),
            ],
          ),
        );
      }),
    );
  }
}

class DashboardPage extends StatelessWidget {
  final String role;
  final String Function(String, String) t;
  const DashboardPage({super.key, required this.role, required this.t});

  @override
  Widget build(BuildContext context) {
    final isClient = role == 'Client';
    final isEmployee = role == 'Employee';
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        Text(t('Welcome to your workspace', 'آپ کے ورک اسپیس میں خوش آمدید'),
          style: const TextStyle(color: Colors.white70, fontSize: 14)),
        const SizedBox(height: 5),
        Text(role == 'Owner' ? t('Agency overview', 'ایجنسی کا خلاصہ') :
          role == 'Employee' ? t('My work', 'میرا کام') : t('My account', 'میرا اکاؤنٹ'),
          style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: gold)),
        const SizedBox(height: 18),
        if (!isClient) Wrap(spacing: 10, runSpacing: 10, children: [
          MetricCard(title: t('Clients', 'کلائنٹس'), value: '0', icon: Icons.people_outline),
          MetricCard(title: t('Active projects', 'فعال پروجیکٹس'), value: '0', icon: Icons.work_outline),
          MetricCard(title: t('Income', 'آمدنی'), value: 'Rs 0', icon: Icons.trending_up),
          MetricCard(title: t('Expenses', 'اخراجات'), value: 'Rs 0', icon: Icons.receipt_long),
        ]) else const MetricCard(title: 'My projects', value: '0', icon: Icons.work_outline),
        const SizedBox(height: 22),
        Text(t('Quick actions', 'فوری اقدامات'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        if (role == 'Owner') ...[
          ActionTile(icon: Icons.person_add_alt, title: t('Add a client', 'کلائنٹ شامل کریں'),
            subtitle: t('Create a client record', 'کلائنٹ کا ریکارڈ بنائیں')),
          ActionTile(icon: Icons.add_task, title: t('Create a project', 'پروجیکٹ بنائیں'),
            subtitle: t('Plan work and deadlines', 'کام اور آخری تاریخ طے کریں')),
          ActionTile(icon: Icons.add_card, title: t('Record a payment', 'ادائیگی درج کریں'),
            subtitle: t('Track received payments', 'موصول شدہ ادائیگیاں درج کریں')),
          ActionTile(icon: Icons.person_add, title: t('Invite an employee', 'ملازم کو شامل کریں'),
            subtitle: t('Assign work to your team', 'ٹیم کو کام تفویض کریں')),
        ] else if (isEmployee) ...[
          ActionTile(icon: Icons.task_alt, title: t('My assigned tasks', 'میرے تفویض کردہ کام'),
            subtitle: t('Tasks assigned by the admin', 'ایڈمن کے دیے ہوئے کام')),
        ] else ...[
          ActionTile(icon: Icons.receipt_long, title: t('My invoices', 'میری انوائسز'),
            subtitle: t('View billing records', 'بلنگ ریکارڈ دیکھیں')),
          ActionTile(icon: Icons.insert_chart_outlined, title: t('My reports', 'میری رپورٹس'),
            subtitle: t('View shared performance reports', 'شیئر کردہ کارکردگی رپورٹس')),
        ],
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0x665D4B2A)),
            gradient: const LinearGradient(colors: [Color(0xFF211B10), Color(0xFF111111)]),
          ),
          child: Text(t('Starter preview: sample figures are zero. Connect the secure database before using this app with real client or financial data.',
            'ابتدائی نمونہ: تمام اعداد صفر ہیں۔ حقیقی کلائنٹ یا مالی معلومات استعمال کرنے سے پہلے محفوظ ڈیٹابیس منسلک کریں۔'),
            style: const TextStyle(color: Colors.white70, height: 1.5)),
        )
      ],
    );
  }
}

class MetricCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const MetricCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: (MediaQuery.of(context).size.width - 42) / 2,
    child: Card(child: Padding(
      padding: const EdgeInsets.all(15),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: gold), const SizedBox(height: 13),
        Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ]),
    )),
  );
}

class ActionTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const ActionTile({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(icon, color: gold), title: Text(title),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54)),
      trailing: const Icon(Icons.chevron_right, color: gold),
      onTap: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This feature will be connected in the next development stage.')),
      ),
    ),
  );
}

class RecordsPage extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  const RecordsPage({super.key, required this.title, required this.icon, required this.subtitle});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: gold, size: 54), const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontSize: 23, color: gold, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
        const SizedBox(height: 15),
        const Text('Coming in the next build', style: TextStyle(color: Colors.white38, fontSize: 12)),
      ]),
    ),
  );
}
