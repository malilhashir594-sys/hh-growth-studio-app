HH GROWTH STUDIO ANDROID STARTER
=================================

This is the first Flutter UI prototype, not a production-ready agency system.

Included:
- Black/gold theme
- English/Urdu interface toggle (starter labels)
- Owner / Employee / Client role preview switcher
- Dashboard and navigation tabs
- Starter cards for clients, projects, finance and social accounts

Not yet included:
- Real authentication or role permissions
- Database or cloud sync
- Client/employee invitations
- Real invoices, payment processing or accounting
- Meta/Instagram account connection
- Production security or backups

IMPORTANT:
Do not enter real client details, passwords, bank details or financial records into this prototype.
Role selection is only a visual demo, not secure authorization.

BUILD FROM ANDROID PHONE (cloud build route):
1. Create/sign in to GitHub in Chrome.
2. Create a NEW public repository named hh-growth-studio-app (public repositories allow GitHub Actions standard usage within its free limits; check current limits).
3. Upload all files/folders from this project ZIP to the repository, preserving folder paths.
4. Open the Actions tab and enable workflows if GitHub asks.
5. Choose "Build Android APK" and tap "Run workflow".
6. When complete, open the run and download the artifact named hh-growth-studio-apk.
7. Extract the artifact ZIP to get app-release.apk and install it on your Android phone.
You may need Chrome's Desktop site mode. GitHub UI may change.

To develop on a computer:
- Install Flutter SDK and Android SDK.
- Run: flutter pub get
- Run: flutter run
- Build APK: flutter build apk --release

NEXT DEVELOPMENT STAGE:
Connect Supabase Auth + Postgres with Row Level Security. Never expose service_role keys in the app. Add database policies so clients only read their own records and employees only access assigned work. Add admin roles using trusted server-side claims / controlled profile records, not a user-editable role dropdown.
